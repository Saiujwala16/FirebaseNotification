
const firebaseConfig = {
  apiKey: "AIzaSyByyK5Dr-zdosD_ya0bTWd_eh6snG-ClHo",
  authDomain: "hong-kong-ml-276902.firebaseapp.com",
  projectId: "hong-kong-ml-276902",
  storageBucket: "hong-kong-ml-276902.appspot.com",
  messagingSenderId: "528736251071",
  appId: "1:528736251071:web:866caeb7372a91bf66ea0a",
  measurementId: "G-M8CG5BXR0Q"
};
server key - AAAAexsi7L8:APA91bEKjqneJAzaeNSycguHcbRKk6gtQEkQwvFts6Rp52sTnnQ-0jBHPL_wftfOpR8_dC1oF6BcjpLpmO9SXxkcuqp1YIByBx4ZIBpoXB-nvdlLY-_3zF8pkga5DvcxqNy_fdOv0-_-
